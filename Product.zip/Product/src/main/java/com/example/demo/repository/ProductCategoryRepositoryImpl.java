package com.example.demo.repository;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.ProductCategory;

@Repository
public class ProductCategoryRepositoryImpl implements ProductCategoryRepository {
	
	@Autowired
	EntityManager entityManager;
	
	public List<ProductCategory> findAll() {
		
		Session currentSession = entityManager.unwrap(Session.class);
		
		Query<ProductCategory> query=currentSession.createQuery("select pc from ProductCategory pc",ProductCategory.class);
		
		List<ProductCategory> productcategorylist = query.getResultList();
		
		return productcategorylist;

	}

	@Override
	public ProductCategory findByID(int id) {
		Session currentSession = entityManager.unwrap(Session.class);
		return currentSession.get(ProductCategory.class,id);
	}

	@Override
	public void save(ProductCategory pc) {
		Session currentSession = entityManager.unwrap(Session.class);
		currentSession.save(pc);
		
	}

	@Override
	public void deleteById(int id) {
		Session currentSession = entityManager.unwrap(Session.class);
		
		Query<ProductCategory> query=currentSession.createQuery("delete from ProductCategory where id = :categoryid");
		query.setParameter("categoryid",id);
		query.executeUpdate();
	}
	
}
