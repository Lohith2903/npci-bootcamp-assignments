package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Product;
import com.example.demo.repository.ProductRepositoryImpl;

@Service
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	ProductRepositoryImpl product;
	
	public List<Product> findAll() {
		return product.findAll();
	}

	@Override
	public Product findByID(int id) {
		return product.findByID(id);
	}

	@Override
	public void save(Product p) {
		product.save(p);
		
	}

	@Override
	public void deleteById(int id) {
		product.deleteById(id);
		
	}
	
	
}
