package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.ProductCategory;
import com.example.demo.repository.ProductCategoryRepositoryImpl;

@Service
public class ProductCategoryServiceImpl implements ProductCategoryService {

	@Autowired
	ProductCategoryRepositoryImpl productcategory;
	
	public List<ProductCategory> findAll() {
		return productcategory.findAll() ;
	}

	@Override
	public ProductCategory findByID(int id) {
	
		return productcategory.findByID(id);
	}

	@Override
	public void save(ProductCategory pc) {
		productcategory.save(pc);
		
	}

	@Override
	public void deleteById(int id) {
		productcategory.deleteById(id);
		
	}

}
