package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.example.demo.entity.ProductCategory;
import com.example.demo.service.ProductCategoryService;

@RestController
@RequestMapping("/productcategory")
public class ProductCategoryController {
	
	@Autowired
	private ProductCategoryService productcategoryservice;
	
	@GetMapping("/productcategorylist")
	public List<ProductCategory> findAll(){
		return productcategoryservice.findAll();
	}
	@GetMapping("productcategory/{id}")
	public ProductCategory showByID(@PathVariable int id)  throws Exception{
		ProductCategory pc = productcategoryservice.findByID(id);
		if(pc == null)
			throw new Exception("Category ID : " + id + " details not found" );
		
		return pc;
	}
	
	@PutMapping("/productcategory")
	public ProductCategory save(@RequestBody ProductCategory pc) {
		pc.setCategoryid(0);
		productcategoryservice.save(pc);
		return pc;
	}
	@DeleteMapping("/product/{id}")
	public String delete(@PathVariable int id) throws Exception {
		ProductCategory pc = productcategoryservice.findByID(id);
		if(pc == null)
			throw new Exception("ProductID " + id +" details not found");
		
		productcategoryservice.deleteById(id);
		return "ProductID" + id + " has been deleted....";
	}
	
}
