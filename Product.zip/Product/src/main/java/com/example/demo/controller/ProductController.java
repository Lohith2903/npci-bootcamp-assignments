package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Product;
import com.example.demo.service.ProductService;

@RestController
@RequestMapping("/product")
public class ProductController {
	
	@Autowired
	private ProductService proservice;
	
	@GetMapping("/productlist")
	public List<Product> findAll(){
		return proservice.findAll();
	}
	
	@GetMapping("product/{id}")
	public Product showByID(@PathVariable int id)  throws Exception{
		Product p = proservice.findByID(id);
		if(p == null)
			throw new Exception("Product ID : " + id + " details not found" );
		
		return p;
	}
	
	@PutMapping("/product")
	public Product save(@RequestBody Product p) {
		p.setId(0);
		proservice.save(p);
		return p;
	}
	
	@DeleteMapping("/product/{id}")
	public String delete(@PathVariable int id) throws Exception {
		Product p = proservice.findByID(id);
		if(p == null)
			throw new Exception("ProductID " + id +" details not found");
		
		proservice.deleteById(id);
		return "ProductID" + id + " has been deleted....";
		
		
		
		
		
	}
	
}
