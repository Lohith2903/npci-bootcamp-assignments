package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.ProductCategory;

public interface ProductCategoryService {
	public List<ProductCategory> findAll();
	public ProductCategory findByID(int id);
	public void save(ProductCategory pc);
	public void deleteById(int id);
}
