package com.example.demo.repository;

import java.util.List;

import com.example.demo.entity.Product;

public interface ProductRepository {
	public List<Product> findAll();
	public Product findByID(int id);
	public void save(Product p);
	public void deleteById(int id);
}
