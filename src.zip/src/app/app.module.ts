import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule} from '@angular/common/http';
import { AppComponent } from './app.component';
import { Routes,RouterModule } from '@angular/router';
import { ProductListComponent } from './component/product-list/product-list.component';
import { ProductcategoryListComponent } from './component/productcategory-list/productcategory-list.component';
import { ProductFormComponent } from './component/product-form/product-form.component';
import { ProductcategoryFormComponent } from './component/productcategory-form/productcategory-form.component';
import { WelcomeComponent } from './component/welcome/welcome.component';
import { MerchantComponent } from './component/merchant/merchant.component';
import { BuyerComponent } from './component/buyer/buyer.component';


const routes : Routes=[
  {path: '', component:MerchantComponent},
  {path: 'buyergrid',component:BuyerComponent},
  {path: '',component: WelcomeComponent},
  {path: 'products',component:ProductListComponent},
  {path:'productcategory',component:ProductcategoryListComponent},
  {path: 'productform',component: ProductFormComponent},
  {path:'productcategoryform',component:ProductcategoryFormComponent}
]


@NgModule({
  declarations: [
    AppComponent,
    ProductListComponent,
    ProductcategoryListComponent,
    ProductFormComponent,
    ProductcategoryFormComponent,
    BuyerComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    RouterModule.forRoot(routes),
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
