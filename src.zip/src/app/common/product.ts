export class Product {
    constructor(public id:number,
                public sku: string,
                public name:String,
                public description : string,
                public unitprice : number,
                public imageurl : string,
                public unitsinstock:number,
                public datecreated : String,
                public lastupdated : String,
                public catgoryid : number
    ){

    }
}
