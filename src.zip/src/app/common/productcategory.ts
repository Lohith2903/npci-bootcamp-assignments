export class Productcategory {

    constructor(public categoryid: number,
                public categoryname:string){

    }
}
