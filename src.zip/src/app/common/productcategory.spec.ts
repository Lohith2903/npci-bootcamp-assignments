import { Productcategory } from './productcategory';

describe('Productcategory', () => {
  it('should create an instance', () => {
    expect(new Productcategory()).toBeTruthy();
  });
});
