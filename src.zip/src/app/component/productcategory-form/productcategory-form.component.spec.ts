import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductcategoryFormComponent } from './productcategory-form.component';

describe('ProductcategoryFormComponent', () => {
  let component: ProductcategoryFormComponent;
  let fixture: ComponentFixture<ProductcategoryFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProductcategoryFormComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProductcategoryFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
