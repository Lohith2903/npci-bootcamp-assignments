import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-productcategory-form',
  templateUrl: './productcategory-form.component.html',
  styleUrls: ['./productcategory-form.component.css']
})
export class ProductcategoryFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
