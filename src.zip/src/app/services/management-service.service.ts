import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable ,map} from 'rxjs';
import { Product } from '../common/product';
import { Productcategory } from '../common/productcategory';

@Injectable({
  providedIn: 'root'
})
export class ManagementServiceService {

  producturl="http://localhost:8080/api/product"
  productcategoryurl="http://localhost:8080/api/productcategory"
  constructor(private httpClient : HttpClient) { }
  getAllProducts() : Observable<Product[]>{

    console.log(this.httpClient.get<getProductResponse>(this.producturl).pipe(map(response => response._embedded.products)))
    return this.httpClient.get<getProductResponse>(this.producturl).pipe(map(response => response._embedded.products))
  }

  getAllProductCategories() : Observable<Productcategory[]>{

    console.log(this.httpClient.get<getProductCategoryResponse>(this.productcategoryurl).pipe(map(response => response._embedded.productCategories)))
    return this.httpClient.get<getProductCategoryResponse>(this.productcategoryurl).pipe(map(response => response._embedded.productCategories))
  }
  saveProduct(products : Product): Observable<Product>{
    console.log(products)

    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type' : 'application/json',
        'Authorization' : 'auth-token',
        'Access-Control-Allow-origin': '*'
      })
    }
    return this.httpClient.post<Product>(this.producturl,products,httpOptions);
  }
}



interface getProductResponse{
  _embedded : {
    products : Product[]
  }
}

interface getProductCategoryResponse{
  _embedded : {
    productCategories : Productcategory[]
  }
}